"""
#------------------------------------------------------------------
# Project: Structure Aware Learnable Multi-Scale Attention for Retinal Vessel Analysis
# ------------------------------------------------------------------
"""
import os
import re
import pandas as pd
import numpy as np
from scipy import stats


# ==========================================================
# BASE PATH
# ==========================================================
BASE = "/home/chandan-v1/Downloads/RESULTS/NETWORKS"

# ==========================================================
# CONFIG
# ==========================================================
datasets = ["DRIVE", "CHASE", "STARE", "CLINICAL"]

models = [
    "UNET",
    "ATTENTION_UNET",
    "CS2_NET",
    "SEGFORMER",
    "TRANS_UNET",
    "SWIN_UNET"
]

conditions = ["LMSA", "plain"]


# ==========================================================
# FILE PATH HELPERS
# ==========================================================
def get_summary_path(model, dataset, condition):
    base_dir = os.path.join(BASE, model, dataset, condition)

    p1 = os.path.join(base_dir, "test_predictions", "metrics_test_summary.txt")
    p2 = os.path.join(base_dir, "metrics_test_summary.txt")

    if os.path.exists(p1): return p1
    if os.path.exists(p2): return p2

    raise FileNotFoundError(f"[SUMMARY NOT FOUND] {model}/{dataset}/{condition}")


def get_per_image_path(model, dataset, condition):
    base_dir = os.path.join(BASE, model, dataset, condition)

    p1 = os.path.join(base_dir, "test_predictions", "metrics_test_per_image.txt")
    p2 = os.path.join(base_dir, "metrics_test_per_image.txt")

    if os.path.exists(p1): return p1
    if os.path.exists(p2): return p2

    raise FileNotFoundError(f"[PER-IMAGE NOT FOUND] {model}/{dataset}/{condition}")


# ==========================================================
# PARSE SUMMARY METRICS (AUTO-FLEXIBLE)
# ==========================================================
pattern = re.compile(r"(Mean[\w\s\(\)-]+):\s*([0-9.]+)")

def parse_summary(path):
    values = {}
    with open(path, "r") as f:
        for line in f:
            m = pattern.match(line.strip())
            if m:
                key = m.group(1).strip()
                val = float(m.group(2)) * 100  # convert to %
                values[key] = val
    return values



# ==========================================================
# LOAD PER-IMAGE METRICS (AUTO-FLEXIBLE)
# ==========================================================
def load_metrics_pair(path_L, path_P):
    
    # Load normally (read header from file)
    df_L = pd.read_csv(path_L)
    df_P = pd.read_csv(path_P)

    # Clean filename spaces
    df_L.iloc[:, 0] = df_L.iloc[:, 0].astype(str).str.strip().str.replace(" ", "")
    df_P.iloc[:, 0] = df_P.iloc[:, 0].astype(str).str.strip().str.replace(" ", "")

    # Determine common filenames
    common = sorted(set(df_L.iloc[:, 0]) & set(df_P.iloc[:, 0]))
    if not common:
        raise ValueError("❌ No matching filenames!")

    # Filter only common
    df_L = df_L[df_L.iloc[:, 0].isin(common)].sort_values(df_L.columns[0]).reset_index(drop=True)
    df_P = df_P[df_P.iloc[:, 0].isin(common)].sort_values(df_P.columns[0]).reset_index(drop=True)

    # Determine metric columns dynamically (all except filename)
    metric_cols = df_L.columns[1:].tolist()

    # Convert to percent
    for m in metric_cols:
        df_L[m] *= 100
        df_P[m] *= 100

    return df_L, df_P, metric_cols



# ==========================================================
# PART 1 — SUMMARY EXCEL (FULLY FLEXIBLE)
# ==========================================================
writer1 = pd.ExcelWriter("LMSA_summary_tables.xlsx", engine="xlsxwriter")

for model in models:

    rows = []
    summary_keys = None

    for ds in datasets:

        L = parse_summary(get_summary_path(model, ds, "LMSA"))
        P = parse_summary(get_summary_path(model, ds, "plain"))

        if summary_keys is None:
            summary_keys = sorted(L.keys())

    for k in summary_keys:
        row = {"Metric": k}

        for ds in datasets:
            L = parse_summary(get_summary_path(model, ds, "LMSA"))
            P = parse_summary(get_summary_path(model, ds, "plain"))

            row[f"{ds}_LMSA"] = L.get(k, "NA")
            row[f"{ds}_plain"] = P.get(k, "NA")

        rows.append(row)

    pd.DataFrame(rows).to_excel(writer1, sheet_name=model, index=False)

writer1.close()
print("✔ Summary tables saved → LMSA_summary_tables.xlsx")



# ==========================================================
# PART 2 — PER-IMAGE STATISTICS (FULLY FLEXIBLE)
# ==========================================================
rows = []

for ds in datasets:
    for model in models:

        df_L, df_P, metric_cols = load_metrics_pair(
            get_per_image_path(model, ds, "LMSA"),
            get_per_image_path(model, ds, "plain")
        )

        for m in metric_cols:

            A = df_L[m].values
            B = df_P[m].values
            diff = A - B

            t, p = stats.ttest_rel(A, B, nan_policy="omit")

            if p < 0.001: sig = "*** (p<0.001)"
            elif p < 0.01: sig = "** (p<0.01)"
            elif p < 0.05: sig = "* (p<0.05)"
            else: sig = ""

            rows.append({
                "Dataset": ds,
                "Model": model,
                "Metric": m,
                "Mean_LMSA": A.mean(),
                "Mean_plain": B.mean(),
                "Mean_diff": diff.mean(),
                "p_value": p,
                "Sig": sig
            })

df_stats = pd.DataFrame(rows)
df_stats.to_csv("lmsa_significance_percent_values.csv", index=False)

print("✔ Per-image CSV saved → lmsa_significance_percent_values.csv")



# ==========================================================
# PART 3 — SIGNIFICANCE EXCEL (FULLY FLEXIBLE)
# ==========================================================
writer2 = pd.ExcelWriter("LMSA_significance_tables.xlsx", engine="xlsxwriter")

def fmt(v, sig):
    return f"{v:+.4f} {sig}"

for model in models:

    table = []
    mlist = sorted(df_stats[df_stats["Model"] == model]["Metric"].unique())

    for m in mlist:
        row = {"Metric": m}

        for ds in datasets:
            sub = df_stats[
                (df_stats["Dataset"] == ds) &
                (df_stats["Model"] == model) &
                (df_stats["Metric"] == m)
            ]

            if sub.empty:
                row[ds] = "NA"
            else:
                row[ds] = fmt(sub["Mean_diff"].values[0], sub["Sig"].values[0])

        table.append(row)

    pd.DataFrame(table).to_excel(writer2, sheet_name=model, index=False)

writer2.close()
print("✔ Significance tables saved → LMSA_significance_tables.xlsx")

print("\n ALL PROCESSING COMPLETE — FULLY FLEXIBLE VERSION READY!")


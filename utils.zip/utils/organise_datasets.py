"""
Dataset Organizer for DRIVE, STARE, CHASEDB1
Compatible with the provided folder structure
"""

import os
import glob
import gzip
from PIL import Image

# =========================================================
# PATH CONFIGURATION
# =========================================================
SOURCE_ROOT = "./data"
TARGET_ROOT = "./DATASETS"

# =========================================================
# CREATE STANDARD STRUCTURE
# =========================================================
def setup_unified_structure(root_path):
    folders = [
        "Train/images",
        "Train/mask",
        "Test/images",
        "Test/mask"
    ]

    for f in folders:
        os.makedirs(os.path.join(root_path, f), exist_ok=True)


# =========================================================
# IMAGE CONVERSION FUNCTION
# =========================================================
def save_as_png(src_path, dest_path):
    try:
        if src_path.endswith(".gz"):
            with gzip.open(src_path, "rb") as f:
                img = Image.open(f)
                img.save(dest_path, "PNG")
        else:
            img = Image.open(src_path)
            img.save(dest_path, "PNG")

    except Exception as e:
        print(f"Error processing {src_path}: {e}")


# =========================================================
# DRIVE DATASET
# =========================================================
def organize_drive(raw_path, target_path):

    print("Organizing DRIVE dataset")

    setup_unified_structure(target_path)

    # TRAIN IMAGES
    for img in glob.glob(os.path.join(raw_path, "training/images/*.tif")):

        name = os.path.basename(img).replace("_training.tif", ".png")

        save_as_png(img, os.path.join(target_path, "Train/images", name))

    # TRAIN MASKS
    for mask in glob.glob(os.path.join(raw_path, "training/1st_manual/*.gif")):

        name = os.path.basename(mask).replace("_manual1.gif", ".png")

        save_as_png(mask, os.path.join(target_path, "Train/mask", name))

    # TEST IMAGES
    for img in glob.glob(os.path.join(raw_path, "test/images/*.tif")):

        name = os.path.basename(img).replace("_test.tif", ".png")

        save_as_png(img, os.path.join(target_path, "Test/images", name))

    # TEST MASKS
    for mask in glob.glob(os.path.join(raw_path, "test/1st_manual/*.gif")):

        name = os.path.basename(mask).replace("_manual1.gif", ".png")

        save_as_png(mask, os.path.join(target_path, "Test/mask", name))

    print("DRIVE done")


# =========================================================
# STARE DATASET
# =========================================================
def organize_stare(raw_path, target_path):

    print("Organizing STARE dataset")

    setup_unified_structure(target_path)

    img_dir = os.path.join(raw_path, "stare-images")
    lbl_dir = os.path.join(raw_path, "labels-ah")

    test_ids = ["im0077", "im0081", "im0082", "im0163", "im0235"]

    images = glob.glob(os.path.join(img_dir, "*.ppm.gz"))

    for img in images:

        base = os.path.basename(img).replace(".ppm.gz", "")

        mask = os.path.join(lbl_dir, base + ".ah.ppm.gz")

        split = "Test" if base in test_ids else "Train"

        if os.path.exists(mask):

            save_as_png(img, os.path.join(target_path, split, "images", base + ".png"))

            save_as_png(mask, os.path.join(target_path, split, "mask", base + ".png"))

    print("STARE done")


# =========================================================
# CHASEDB1 DATASET
# =========================================================
def organize_chase(raw_path, target_path):

    print("Organizing CHASEDB1 dataset")

    setup_unified_structure(target_path)

    test_filenames = ["Image_01L", "Image_01R", "Image_02L", "Image_02R", "Image_03L"]

    images = glob.glob(os.path.join(raw_path, "*.jpg"))

    for img in images:

        base = os.path.basename(img).replace(".jpg", "")

        mask = os.path.join(raw_path, base + "_1stHO.png")

        split = "Test" if base in test_filenames else "Train"

        if os.path.exists(mask):

            save_as_png(img, os.path.join(target_path, split, "images", base + ".png"))

            save_as_png(mask, os.path.join(target_path, split, "mask", base + ".png"))

    print("CHASEDB1 done")


# =========================================================
# MAIN EXECUTION
# =========================================================
if not os.path.exists(SOURCE_ROOT):
    print("Dataset folder not found")

else:

    drive_path = os.path.join(SOURCE_ROOT, "Drive")
    stare_path = os.path.join(SOURCE_ROOT, "Stare")
    chase_path = os.path.join(SOURCE_ROOT, "CHASEDB1")

    if os.path.exists(drive_path):
        organize_drive(drive_path, os.path.join(TARGET_ROOT, "DRIVE"))

    if os.path.exists(stare_path):
        organize_stare(stare_path, os.path.join(TARGET_ROOT, "STARE"))

    if os.path.exists(chase_path):
        organize_chase(chase_path, os.path.join(TARGET_ROOT, "CHASEDB1"))

    print("\nSUCCESS: All datasets processed")

"""
# ------------------------------------------------------------------
# Project: Structure Aware Learnable Multi-Scale Attention for Retinal Vessel Analysis
#-------------------------------------------------------------------
"""
import os
import shutil
import glob
import gzip
import numpy as np
from PIL import Image
from pathlib import Path

# ==================================================================
# CONFIGURATION (Automatic Paths)
# ==================================================================
SOURCE_ROOT = "./datasets"  # Folder containing raw downloads
TARGET_ROOT = "./DATASETS"  # Destination for organized datasets

# ==================================================================
# UTILITY FUNCTIONS
# ==================================================================
def setup_unified_structure(root_path):
    """Creates the standard folder hierarchy."""
    folders = ['Train/images', 'Train/mask', 'Test/images', 'Test/mask']
    for folder in folders:
        os.makedirs(os.path.join(root_path, folder), exist_ok=True)

def save_as_png(src_path, dest_path):
    """Reads various formats (tif, gif, jpg, ppm, gz) and saves as png."""
    try:
        if src_path.endswith('.gz'):
            with gzip.open(src_path, 'rb') as f:
                img = Image.open(f)
                img.save(dest_path, 'PNG')
        else:
            img = Image.open(src_path)
            img.save(dest_path, 'PNG')
    except Exception as e:
        print(f"Error processing {src_path}: {e}")

# ==================================================================
# DATASET SPECIFIC LOGIC
# ==================================================================
def organize_drive(raw_path, target_path):
    print(f"--- Organizing DRIVE dataset ---")
    setup_unified_structure(target_path)
    # Training
    for img in glob.glob(os.path.join(raw_path, "training/images/*.tif")):
        name = os.path.basename(img).replace(".tif", ".png")
        save_as_png(img, os.path.join(target_path, "Train/images", name))
    for mask in glob.glob(os.path.join(raw_path, "training/1st_manual/*.gif")):
        name = os.path.basename(mask).replace("_manual1.gif", ".png")
        if "training" not in name: name = name.replace("_manual1", "_training")
        save_as_png(mask, os.path.join(target_path, "Train/mask", name))
    # Test
    for img in glob.glob(os.path.join(raw_path, "test/images/*.tif")):
        name = os.path.basename(img).replace(".tif", ".png")
        save_as_png(img, os.path.join(target_path, "Test/images", name))
    for mask in glob.glob(os.path.join(raw_path, "test/mask/*.gif")):
        name = os.path.basename(mask).replace("_test_mask.gif", "_test.png")
        save_as_png(mask, os.path.join(target_path, "Test/mask", name))
    print(f"Done: {target_path}")

def organize_chase(raw_path, target_path):
    print(f"--- Organizing CHASE_DB1 dataset ---")
    setup_unified_structure(target_path)
    # Test split based on specific filenames provided
    test_filenames = ["Image_01L", "Image_01R", "Image_02L", "Image_02R", "Image_03L"]
    all_imgs = glob.glob(os.path.join(raw_path, "*.jpg"))
    for img_path in all_imgs:
        base_name = os.path.basename(img_path).replace(".jpg", "")
        mask_path = os.path.join(raw_path, base_name + "_1stHO.png")
        target = "Test" if base_name in test_filenames else "Train"
        if os.path.exists(mask_path):
            save_as_png(img_path, os.path.join(target_path, target, "images", base_name + ".png"))
            save_as_png(mask_path, os.path.join(target_path, target, "mask", base_name + ".png"))
    print(f"Done: {target_path}")

def organize_stare(raw_path, target_path):
    print(f"--- Organizing STARE dataset ---")
    setup_unified_structure(target_path)
    img_dir = os.path.join(raw_path, "stare-images")
    lbl_dir = os.path.join(raw_path, "labels-ah")
    # Test split based on specific IDs provided
    test_ids = ["im0077", "im0081", "im0082", "im0163", "im0235"]
    all_gz_imgs = glob.glob(os.path.join(img_dir, "*.ppm.gz"))
    for img_gz in all_gz_imgs:
        base_id = os.path.basename(img_gz).replace(".ppm.gz", "")
        mask_gz = os.path.join(lbl_dir, base_id + ".ah.ppm.gz")
        target = "Test" if base_id in test_ids else "Train"
        if os.path.exists(mask_gz):
            save_as_png(img_gz, os.path.join(target_path, target, "images", base_id + ".png"))
            save_as_png(mask_gz, os.path.join(target_path, target, "mask", base_id + ".png"))
    print(f"Done: {target_path}")

# ==================================================================
# EXECUTION BLOCK
# ==================================================================
if not os.path.exists(SOURCE_ROOT):
    print(f"[!] Error: '{SOURCE_ROOT}' folder not found. Please place raw data in a folder named 'datasets'.")
else:
    # 1. DRIVE
    drive_path = os.path.join(SOURCE_ROOT, "archive", "DRIVE")
    if os.path.exists(drive_path):
        organize_drive(drive_path, os.path.join(TARGET_ROOT, "DRIVE_dataset"))
    
    # 2. CHASEDB1
    chase_path = os.path.join(SOURCE_ROOT, "CHASEDB1")
    if os.path.exists(chase_path):
        organize_chase(chase_path, os.path.join(TARGET_ROOT, "Chase_DB1"))
        
    # 3. STARE
    stare_path = os.path.join(SOURCE_ROOT, "stare-images")
    if os.path.exists(stare_path):
        organize_stare(SOURCE_ROOT, os.path.join(TARGET_ROOT, "stare"))
        
    print("\n[SUCCESS] All detected datasets have been organized and standardized to .png")
